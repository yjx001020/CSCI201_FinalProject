import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
	public ArrayList<StudentS> mainQueue;
	public HashSet<FacultyS> faculty;
	public ExecutorService executors = Executors.newCachedThreadPool();
	private PrintWriter pw;
	private BufferedReader br;
	
	public static void main(String[] args) {
		Server server = new Server(3456);
	}
	
	public Server(int port) {
		try {
			System.out.println("Binding to port " + port);
			ServerSocket ss = new ServerSocket(port);
			mainQueue = new ArrayList<StudentS>();
			//connection
			while(true) {
				Socket s = ss.accept(); // blocking
				System.out.println("Connection from: " + s.getInetAddress());
				//read message
				br = new BufferedReader(new InputStreamReader(s.getInputStream()));
				String line;
				String type = null;
				String passWard = null;
				int id = -1;
				while ((line = br.readLine()) != null) {
			        String[] values = line.split(",");
			        type = values[0];
			        id = Integer.parseInt(values[1]);
			        passWard = values[2];
				}
				if(type.equals("S")){//student connect
					StudentS studentS = new StudentS(id,passWard,this,s);
				}else if(type.equals("F")){
					FacultyS facultyF = new FacultyS(id,passWard,this,s);
				}else {
					pw.println("Invalid username and password");
					pw.flush();
				}
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatRoom constructor: " + ioe.getMessage());
		}
	}
	
	public void boardcastClose() {
		for(int i = 0; i < mainQueue.size(); i++) {
			mainQueue.get(i).sendMessageClose();
		}
		for(FacultyS fThread : faculty) {
			fThread.sendMessageClose();
		}
	}
	public void boardcastMessage(String message) {
		for(int i = 0; i < mainQueue.size(); i++) {
			mainQueue.get(i).sendMessageFaculty(message);
		}
		for(FacultyS fThread : faculty) {
			fThread.sendMessageFaculty(message);
		}
	}
	public void boardcast() {
		int totalStudent = mainQueue.size()-1;
		for(int i = 0; i < mainQueue.size(); i++) {
			mainQueue.get(i).sendMessage(i,totalStudent);
		}
		for(FacultyS fThread : faculty) {
			fThread.sendMessage(totalStudent);
		}
	}

}
