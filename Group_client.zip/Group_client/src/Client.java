import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;



public class Client {
	public BufferedReader br;
	public PrintWriter pw;
	public Socket s;
	public boolean running;
	public boolean login;
	public int position;
	public int queue_size;
	public Person user;
	private String ans;
	private String myid;
	public Client(String hostname, int port) {
		//establishing connection
		try {
			s = new Socket(hostname, port);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());
			running=true;
			login=false;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		//logging in
		Scanner in=new Scanner(System.in);
		System.out.println("Are you a student or a faculty?S/F");
		ans= in.nextLine();
		System.out.println("Please enter your id");
		myid=in.nextLine();
		System.out.println("Please enter your password");
		String pasw=in.nextLine();
		pw.println(ans+","+myid+","+pasw);
		pw.flush();
		//start listening
		while(!login) {
			try {
				String order=br.readLine();
				if(order==null) {
					//do nothing
				}
				else if(order.compareTo("Success")==0) {
					String[] info_list=order.split(",");
					if(ans.compareTo("S")==0) {
						user=new Student(info_list[1], myid, this);
					}
					else {
						user=new Faculty(info_list[1], myid, this);
					}
					login=true;
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		while(running) {
			try {
				String order=br.readLine();
				if(order==null) {
					//do nothing
				}
				else if(order.substring(0, 14).compareTo("upDateMessage: ")==0) {
					String[] info_list=order.split(",");
					position=Integer.parseInt(info_list[1]);
					queue_size=Integer.parseInt(info_list[2]);
				}
				else if(order.compareTo("Close")==0) {
					running=false;
				}
				else {
					System.out.println(order);
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		in.close();
		try {
			s.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
